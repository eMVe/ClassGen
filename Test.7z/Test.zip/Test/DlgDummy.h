#pragma once

#include "easysize.h"

#define DATA_READY (WM_USER + 110)

class DlgDummy : public CDialog
{
//	enum {
//		SYS_MESSAGE,
//		DATA_MESSAGE
//	};
	CString m_fontFaceName;
	int	m_fontSize;
	LONG m_fontWeight;
	CFont m_font;

	DECLARE_EASYSIZE;
	afx_msg void OnSize(UINT nType, int cx, int cy);

	HANDLE m_mutex;
	unsigned int m_threadHandle;
	volatile bool m_bThreadRunning;

	void threadStart();
	static unsigned int __stdcall threadLauncher(void *p_this);
	void thread();

protected:
	void DoDataExchange(CDataExchange* pDX);
	BOOL PreTranslateMessage (MSG* pMsg);
	BOOL OnInitDialog();
	void OnCancel();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnClose();
	afx_msg void OnOK();
	afx_msg LRESULT OnDataReady(WPARAM wParam, LPARAM lParam);
public:
	void presetFont(const char *fontFaceName, int size, int weight);
	virtual INT_PTR DoModal();
	DlgDummy(CWnd* pParent);
	~DlgDummy();
};
